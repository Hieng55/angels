import './next.css';

export const metadata = {
  title: 'Angel Nail Spa & Permanent Makeup | Yakima, WA',
  description: 'Angel Nail Spa & Permanent Makeup in Yakima, WA — thoughtful nail care, spa pedicures, and permanent makeup in a serene setting.',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#679cbc',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://images.unsplash.com" />
        <link href="https://fonts.googleapis.com/css2?family=Forum&family=Jost:wght@400;500;600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="/styles.css" />
      </head>
      <body>{children}</body>
    </html>
  );
}

'use client';

import { useEffect, useState } from 'react';
import {
  ArrowDown, ArrowRight, ArrowUpRight, CalendarDays, Check, Clock3,
  Flower2, Gem, Heart, MapPin, Menu, Mouse, Phone, Sparkles, WandSparkles, X
} from 'lucide-react';

const BOOKING = 'https://www.lldtek.org/salon/appt/VjBGZk1USTBNamc9';
const FACEBOOK = 'https://www.facebook.com/angelsnailandpermanentmakeup/';
const INSTAGRAM = 'https://www.instagram.com/angelnailspaandpermanentmakeup/';

function Brand({ footer = false }) {
  return (
    <a className={`brand${footer ? ' footer-brand' : ''}`} href="#home" aria-label="Angel Nail Spa home">
      <svg className="brand-mark" viewBox="0 0 64 64" aria-hidden="true">
        <path d="M32 10c6 7 8 14 0 22-8-8-6-15 0-22Z" />
        <path d="M12 27c9-1 15 2 18 12-11 1-16-4-18-12Z" />
        <path d="M52 27c-9-1-15 2-18 12 11 1 16-4 18-12Z" />
        <path d="M20 48c7-6 14-7 22 0-7 8-15 7-22 0Z" />
        <circle cx="32" cy="38" r="3" />
      </svg>
      <span><strong>Angel</strong><small>NAIL SPA &amp; PERMANENT MAKEUP</small></span>
    </a>
  );
}

function BrandIcon({ name }) {
  return <img src={`https://thesvg.org/icons/${name}/mono.svg`} alt="" />;
}

const services = [
  { no: '01', title: 'Manicure', text: 'Clean shaping, detailed cuticle care, and a beautiful finish made to suit you.', Icon: Sparkles },
  { no: '02', title: 'Pedicure', text: 'Relax, reset, and leave refreshed with soft skin and perfectly polished toes.', Icon: Flower2, featured: true },
  { no: '03', title: 'Nail Enhancements', text: 'Length, strength, and custom artistry designed around your preferred shape and look.', Icon: WandSparkles },
  { no: '04', title: 'Permanent Makeup', text: 'Thoughtful enhancements that simplify your routine and highlight your natural beauty.', Icon: Gem },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState('home');

  useEffect(() => {
    const onScroll = () => {
      const point = window.scrollY + 180;
      const sections = [...document.querySelectorAll('main section[id], header[id]')];
      setActive([...sections].reverse().find(section => section.offsetTop <= point)?.id || 'home');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const nav = ['home', 'services', 'about', 'gallery', 'contact'];
  const label = item => item === 'about' ? 'About us' : item[0].toUpperCase() + item.slice(1);

  return <>
    <header className="site-header" id="home">
      <Brand />
      <nav className="desktop-nav" aria-label="Main navigation">
        {nav.map(item => <a key={item} className={active === item ? 'active' : ''} href={`#${item}`}>{label(item)}</a>)}
      </nav>
      <a className="header-phone" href="tel:+15093172391"><Phone /><span>Call now</span></a>
      <button className="menu-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen(v => !v)}>{menuOpen ? <X /> : <Menu />}</button>
    </header>

    <nav className={`mobile-nav${menuOpen ? ' open' : ''}`} aria-label="Mobile navigation">
      {nav.map(item => <a key={item} href={`#${item}`} onClick={() => setMenuOpen(false)}>{label(item)}</a>)}
    </nav>

    <main>
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-shade" />
        <div className="hero-content reveal">
          <p className="eyebrow"><span /> ANGEL NAIL SPA · YAKIMA</p>
          <h1 id="hero-title">A little heaven<br />at your <em>fingertips.</em></h1>
          <p className="hero-copy">A calm, polished escape for beautiful nails, thoughtful care, and the confidence to feel like your best self.</p>
          <div className="hero-actions">
            <a className="btn btn-light" href={BOOKING} target="_blank" rel="noopener noreferrer">Book appointment <ArrowUpRight /></a>
            <a className="text-link" href="#services">Explore services <ArrowDown /></a>
          </div>
        </div>

        <div className="hero-photo reveal" aria-hidden="true">
          <div className="photo-frame"><div className="photo" /></div>
          <div className="photo-seal"><span>01</span><small>SIGNATURE<br />CARE</small></div>
        </div>

        <div className="hero-location"><span className="pin"><MapPin /></span><span><strong>Angel Nail Spa</strong><small>1415 S 3rd Ave, Unit 400 · Yakima, WA</small></span></div>
        <div className="social-rail" aria-label="Social media">
          <span>FOLLOW</span>
          <a href={FACEBOOK} target="_blank" rel="noopener noreferrer" aria-label="Facebook"><BrandIcon name="facebook" /></a>
          <a href={INSTAGRAM} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><BrandIcon name="instagram" /></a>
        </div>
        <a className="scroll-cue" href="#services"><span><Mouse /></span>SCROLL</a>
      </section>

      <section className="services section" id="services">
        <div className="section-heading reveal">
          <div><p className="eyebrow blue">OUR SERVICES</p><h2>Care made <em>personal.</em></h2></div>
          <p>From everyday polish to statement nails and lasting beauty, every visit is centered around your comfort and style.</p>
        </div>
        <div className="service-grid">
          {services.map(({ no, title, text, Icon, featured }) => <article key={title} className={`service-card reveal${featured ? ' featured' : ''}`}>
            <span>{no}</span><Icon /><h3>{title}</h3><p>{text}</p>
            <a href={BOOKING} target="_blank" rel="noopener noreferrer">Book now <ArrowRight /></a>
          </article>)}
        </div>
      </section>

      <section className="about section" id="about">
        <div className="about-collage reveal">
          <img className="about-main" src="https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=1100&q=85" alt="Elegant manicure with neutral polish" />
          <img className="about-small" src="https://images.unsplash.com/photo-1607779097040-26e80aa78e66?auto=format&fit=crop&w=700&q=85" alt="Nail care detail" />
          <div className="about-badge"><Heart /><span>Made with<br /><strong>care</strong></span></div>
        </div>
        <div className="about-copy reveal">
          <p className="eyebrow blue">WELCOME TO ANGEL</p>
          <h2>Beauty in every <em>detail.</em></h2>
          <p>We believe self-care should feel unhurried, welcoming, and completely yours. Angel Nail Spa &amp; Permanent Makeup brings careful technique and a warm touch to every appointment.</p>
          <div className="about-points">
            <div><Check /><span><strong>Thoughtful care</strong><small>Attention to the details that make your service feel special.</small></span></div>
            <div><Check /><span><strong>Your style, beautifully done</strong><small>Classic, modern, subtle, or bold — the choice is yours.</small></span></div>
          </div>
          <a className="btn btn-blue" href="tel:+15093172391">Talk to our team <Phone /></a>
        </div>
      </section>

      <section className="gallery section" id="gallery">
        <div className="section-heading reveal">
          <div><p className="eyebrow blue">OUR WORK</p><h2>Made to be <em>noticed.</em></h2></div>
          <a className="instagram-link" href={INSTAGRAM} target="_blank" rel="noopener noreferrer"><BrandIcon name="instagram" /> Follow on Instagram</a>
        </div>
        <div className="gallery-grid">
          <figure className="wide reveal"><img src="https://images.unsplash.com/photo-1610992015732-2449b76344bc?auto=format&fit=crop&w=1200&q=85" alt="Polished nail art" /></figure>
          <figure className="reveal"><img src="https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&w=800&q=85" alt="Detailed manicure" /></figure>
          <figure className="reveal"><img src="https://images.unsplash.com/photo-1599206676335-193c82b13c9e?auto=format&fit=crop&w=800&q=85" alt="Elegant nail polish" /></figure>
        </div>
      </section>

      <section className="contact" id="contact">
        <div className="contact-copy reveal">
          <p className="eyebrow">COME VISIT US</p><h2>Your appointment<br />is <em>waiting.</em></h2>
          <p>Set aside a little time for yourself. We’ll take care of the rest.</p>
          <a className="btn btn-light" href={BOOKING} target="_blank" rel="noopener noreferrer">Book appointment <CalendarDays /></a>
        </div>
        <div className="contact-card reveal">
          <div><MapPin /><span><small>VISIT</small><a href="https://maps.google.com/?q=1415+S+3rd+Ave+unit+400+Yakima+WA+98902" target="_blank" rel="noopener noreferrer">1415 S 3rd Ave, Unit 400<br />Yakima, WA 98902</a></span></div>
          <div><Phone /><span><small>CALL</small><a href="tel:+15093172391">(509) 317-2391</a></span></div>
          <div><Clock3 /><span><small>HOURS</small><p><b>Monday</b> Closed<br /><b>Tuesday – Sunday</b> 10:00 AM – 7:00 PM</p></span></div>
        </div>
      </section>
    </main>

    <footer>
      <Brand footer />
      <p>© {new Date().getFullYear()} Angel Nail Spa &amp; Permanent Makeup. All rights reserved.</p>
      <div className="footer-social">
        <a href={FACEBOOK} target="_blank" rel="noopener noreferrer" aria-label="Facebook"><BrandIcon name="facebook" /></a>
        <a href={INSTAGRAM} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><BrandIcon name="instagram" /></a>
      </div>
    </footer>
    <a className="mobile-book" href={BOOKING} target="_blank" rel="noopener noreferrer"><CalendarDays /> Book now</a>
  </>;
}
